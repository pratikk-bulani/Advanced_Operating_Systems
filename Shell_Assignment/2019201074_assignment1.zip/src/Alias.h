/*
 * Alias.h
 *
 */

#ifndef ALIAS_H_
#define ALIAS_H_

#include <map>

using namespace std;

map<string, string> ALIAS_MAP;

#endif /* ALIAS_H_ */
